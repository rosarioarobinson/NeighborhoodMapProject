//Locations array
var dcLocations = [{
        placename: 'National Museum of African American History and Culture',
        lat: 38.891055,
        lng: -77.032704
    },
    {
        placename: 'International Spy Museum',
        lat: 38.896945,
        lng: -77.023617
    },
    {
        placename: 'Founding Farmers',
        lat: 38.900285,
        lng: -77.044527
    },
    {
        placename: 'JFK Center for Performing Arts',
        lat: 38.8959,
        lng: -77.054992
    },
    {
        placename: 'Smithsonian National Air and Space Museum',
        lat: 38.88816,
        lng: -77.019868
    },
];
